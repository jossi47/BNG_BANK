<html lang="en">

   
<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

 <title>
        Change Pin    </title>


    <!-- /load styles -->

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="css/style.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-1.11.3.js"></script>
    <script src="tinymce/js/tinymce/jquery.tinymce.min.js"></script>
    <script src="tinymce/js/tinymce/tinymce.min.js"></script>
  <script type="text/javascript">
    tinymce.init({
        selector: 'textarea',
        height: 300,
        theme: 'modern',
        plugins: [
            'advlist autolink lists link image charmap print preview hr anchor pagebreak',
            'searchreplace wordcount visualblocks visualchars code fullscreen',
            'insertdatetime media nonbreaking save table contextmenu directionality',
            'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc'
        ],
        toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
        toolbar2: 'print preview media | forecolor backcolor emoticons | codesample',
        
        image_advtab: true,
        content_css: [
            '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
            '//www.tinymce.com/css/codepen.min.css'
        ]
    });
    
    
</script>
    <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60f28a83649e0a0a5ccca28a/1fapmq4gc';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script--> <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60f28a83649e0a0a5ccca28a/1fapmq4gc';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script--> <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60f28a83649e0a0a5ccca28a/1fapmq4gc';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script--> <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60f28a83649e0a0a5ccca28a/1fapmq4gc';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script--> <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60f28a83649e0a0a5ccca28a/1fapmq4gc';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script--> 

<div id="ytWidget"></div><script src="https://translate.yandex.net/website-widget/v1/widget.js?widgetId=ytWidget&pageLang=en&widgetTheme=light&autoMode=true" type="text/javascript"></script>
        
</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-success sidebar sidebar-dark accordion" id="accordionSidebar" style='font-size: 18px;'>

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="home.php">
      
        <div class="sidebar-brand-text mx-3">
            <img class="img-responsive" style="width: 100px; " src="../images/logo.png " />          </div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="home.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Interface
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-fw fa-cog"></i>
          <span>Account Overview</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            
 
            <a class="collapse-item" href="profile.php">Account Details</a>
                        <a class="collapse-item" href="statement.php">Account Statement</a>
                                    
          </div>
        </div>
      </li><hr class="sidebar-divider">

      <!-- Nav Item - Utilities Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUtilities" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-exchange-alt"></i>
          <span>Fund Transfer</span>
        </a>
        <div id="collapseUtilities" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">

   <a class="collapse-item" href="interbank.php"> Local Transfer</a>
          
              <a class="collapse-item" href="international-transfer.php">International Transfer</a>
            <a class="collapse-item" href="statement.php">Transfer History</a>
           
          </div>
        </div>
      </li>
  <!-- Nav Item - Charts -->
       <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
   Addons
      </div>
      <li class="nav-item">
            <a class="nav-link" href="javascript:void(Tawk_API.toggle())">
          <i class="fas fa-fw fa-comment"></i>
          <span>Live Chat With US</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseU" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-info"></i>
          <span>How safe is my Capital Reliance Bank Visa Credit Card?</span>
        </a>
        <div id="collapseU" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">

  <p>Your Capital Reliance Bank Visa Credit Card is very safe because it has added advantage of Verified by Visa IPIN which ensures that while paying for goods on the internet, ONLY the true owner of a card can authorize payment on the card.<br /><br />

Follow these easy steps next time you're shopping online to activate your Verified by Visa iPIN.<br />
* Click the 'CHECK-OUT' button or the 'PAY-NOW' button while shopping.<br />
* Enter your card details as required by the website.<br />
* The VbyV screen appears on the website.<br />
* Enter your card details.<br />
* Enter ID Number as provide in your Credit card application form.<br />
* Enter Date of birth in the format YYYY as year of birth, MM as month of birth, and DD as day of birth.<br />
* Enter Card expiry date as shown on the card in the format YYYY as year of expiration, and MM as month of expiration<br />
* Click the 'NEXT' button to input a NEW 4 digit PIN.<br />
* Click the 'END' button when done.</p>
           
          </div>
        </div>
      </li>
       <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseU" aria-expanded="true" aria-controls="collapseUtilities">
          <i class="fas fa-info"></i>
          <span>What documentation is required to get a Payroll <br>Credit Card?</span>
        </a>
        <div id="collapseU" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">

  <p>* Duly filled Credit card application form.<br />
* Letter from employer stating irrevocable domiciliation of salary and gratuity/terminal Benefits.<br />
* Letter from employer confirming applicant's monthly, annual salary and length of service with the Organization<br />
* 3 month's Payslip<br />
* Driver's License/International Passport/National Identity Card.<br />
* Photocopy of Employee identity card.<br />
* Current Passport Photograph.<br />
</p>
           
          </div>
        </div>
      </li>
        
           <li class="nav-item">
        <a class="nav-link" href="tickets.php">
          <i class="fas fa-fw fa-envelope"></i>
          <span>Contact Customer Care</span></a>
      </li>
        
        
        <li class="nav-item">
            <a class="nav-link" href="../contact.php" target="_blank">
          <i class="fas fa-fw fa-map-marker"></i>
          <span>Capital Reliance BankNear Me</span></a>
      </li>
      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
    Security Settings
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
          <i class="fas fa-fw fa-wrench"></i>
          <span> Account Quick Links</span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
           
            <a class="collapse-item" href="profile.php">My Profile</a>
            <a class="collapse-item" href="update-profile.php">Edit Profile</a>
            <a class="collapse-item" href="change-pass.php">Change Password</a>
                <a class="collapse-item" href="change-pin.php">Change Pin</a>
           
            <a class="collapse-item" href="index.php?logout"  data-toggle="modal" data-target="#logoutModal">Logout</a>
        
          </div>
        </div>
      </li>

    

      <!-- Nav Item - Tables -->
    

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

        <!-- Topbar -->
        <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

          <!-- Sidebar Toggle (Topbar) -->
          <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>

          

          <!-- Topbar Navbar -->
          <ul class="navbar-nav ml-auto">

            <!-- Nav Item - Search Dropdown (Visible Only XS) -->
            <li class="nav-item dropdown no-arrow d-sm-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
                <form class="form-inline mr-auto w-100 navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-0 small" placeholder="Search for..." aria-label="Search" aria-describedby="basic-addon2">
                    <div class="input-group-append">
                      <button class="btn btn-primary" type="button">
                        <i class="fas fa-search fa-sm"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>

            <!-- Nav Item - Alerts -->
            <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="far fa-bell fa-fw"></i>
                <!-- Counter - Alerts -->
                <span class="badge badge-danger badge-counter">5</span>
              </a>
              <!-- Dropdown - Alerts -->
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-indropdown" aria-labelledby="alertsDropdown">
                <h6 class="dropdown-header">
                 System Alerts Center
                </h6>
                                  <a class="dropdown-item d-flex align-items-center" href="notifications.php?view=12">
                  <div class="mr-3">
                    <div class="icon-circle bg-primary">
                      <i class="fas fa-file-alt text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500" style="color:success;">2020-08-27 17:34:19</div>
                    <div  class="font-weight-bold">You have a new notification </div>
                  </div>
                </a> 
            
               
             
                
                                  <a class="dropdown-item d-flex align-items-center" href="notifications.php?view=7">
                  <div class="mr-3">
                    <div class="icon-circle bg-primary">
                      <i class="fas fa-file-alt text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500" style="color:success;">2020-07-15 00:22:00</div>
                    <div  class="font-weight-bold">GN DIGITAL </div>
                  </div>
                </a> 
            
               
             
                
                     <a class="dropdown-item text-center small text-gray-500" href="notifications.php">Show All Alerts</a>               </div>
            </li>

            <!-- Nav Item - Messages -->
            <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-envelope fa-fw"></i>
                <!-- Counter - Messages -->
                <span class="badge badge-danger badge-counter">0</span>
              </a>
              <!-- Dropdown - Messages -->
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="messagesDropdown">
                <h6 class="dropdown-header">
                  Message Center
                </h6>
                   
                <p class='text-danger'>No Messages Yet!</p>
                                    </div>
            </li>

            <div class="topbar-divider d-none d-sm-block"></div>

            <!-- Nav Item - User Information -->
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-lg-inline text-gray-600 small"> Alexandra Patrick</span>
              
                                                  <img class="img-responsive" style="width: 25px; " src="../uploads/Pat.jpeg" />              </a>
              <!-- Dropdown - User Information -->
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="profile.php">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  My Profile
                </a>
                <a class="dropdown-item" href="statement.php">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Account Statement
                </a>
                <a class="dropdown-item" href="transfer.php">
                  <i class="fas fa-paper-plane fa-sm fa-fw mr-2 text-gray-400"></i>
                  Make A Transfer
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="../online.php" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>

          </ul>

        </nav>
        <!-- End of Topbar -->

          <div id="page-wrapper">
            <div class="row">
                <div class="col-md-12">        
                    
                  <legend style='text-align:center;background-color:#fff;border-radius:5px;height:35px;line-height:35px;color:#FFFFFF;width:200px;font-size:16px'></legend>
	<div id="transfersection" style="">
	</div></fieldset><br />
	<fieldset style='border-radius:5px;border-color:#fff;border-width:1px;border-style:solid;'>
    <div id="fundtransfer" style="padding-left:10px;" >
      
    </div>
   </div>
   </fieldset>
   <div id="containerdetails" style="background-color:#FFFFFF;width:68%;min-height:750px;float:left;background-image:url('../images/watermark2.png');background-repeat:inherit;">
	                   	                    
	 
								 
	  <div id="errsection" style="width:600px;clear:both;display:none;padding:20px;">
       <div id="errhead" style="background-color:#FF0000;border-radius:5px;color:#FFFFFF;font-weight:bold;text-align:center;">ERROR!!!</div>
	   <div id="err" style="color:#000;height:220px;padding:10px;background-color:#FFFFFF;-moz-box-shadow:0px 0px 10px #555555;
	 -webkit-box-shadow:0px 0px 10px #555555;box-shadow:0px 0px 10px #555555;border-radius:5px;border-color:#FFFFFF;font-size:12px;"></div>
	 </div><h3 class="page-header" style="font-weight: bold; color: black;">Change Transaction Pin</h3>
        <div class="col-md-8 offset-2 bg-white">

    <form method="post" action="" name="register">
        <fieldset>
           
            <div class="form-group  "><div class="">
                      <span class="input-group-addon"><i class="fa fa-fw fa-envelope "></i></span>
                <label for='id=inputError'>New Account Pin</label>
                <input  type="password" class="form-control" placeholder="Transaction Pin" name="pin"
                        value=""
 required>
                <span style="color: red;" class="text-capitalize"></span>
                </div></div>
             <div class="form-group "><div class="">
                      <span class="input-group-addon"><i class="fa fa-fw fa-check-square "></i></span>
                <label for='id=inputError'>Confirm Account Pin</label>

                <input  type="password" class="form-control" placeholder="Confirm Transaction Pin" name="cpin"
                        value=""
 required>
                <span style="color: red;" class="text-capitalize"></span>
  
                 </div></div>
            
           
            <!-- Change this to a button or input when using this as a form -->
            <button type="submit" class="btn btn-md btn-primary pull-right">Change Account Pin</button>
        </fieldset>
    </form>

</div>
</div>
<!-- /.row --></div></div>

 <!-- Footer -->
     
      
      <footer class="sticky-footer bg-white">
                    <div> <!-- bottombar Search -->
          <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
        <p>You have logged in from Cyprus
 with IP: 78.135.57.227<br />Today:  23 Nov 2021</p>
          </form></div>
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Capital Reliance Bank  2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="../online.php?logout">Logout</a>
        </div>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="spry/tabbedpanels/SpryTabbedPanels.css"></script>
    <script src="spry/tabbedpanels/SpryTabbedPanels.js"></script>
   <script language="JavaScript" type="text/javascript">
	var tp1 = new Spry.Widget.TabbedPanels("AccountSummaryPanel", { defaultTab: 0});
</script>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>
 
         <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/5ec91ba08ee2956d73a3de3b/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
</body>

</html>
